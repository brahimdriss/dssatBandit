pip3 install --user joblib
pip3 install --user jinja2
pip3 install --user tqdm
pip3 install --user gym
pip3 install --user matplotlib
pip3 install --user seaborn